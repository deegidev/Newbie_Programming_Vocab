function textToggle() {
 var text = document.getElementById("explain"); 
if (text.style.display === "none") {
    text.style.display = "block";
  } else {
    text.style.display = "none";
  }
}